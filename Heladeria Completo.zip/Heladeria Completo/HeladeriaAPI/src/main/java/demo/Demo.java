package demo;

// Importar librerías:
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



public class Demo {
    // Crear método main:
    public static void main(String[] args) {
        // Imprimir mensaje:
        System.out.println("Hola mundo!");
    }

    // Conectar con la base de datos MySQL usando JDBC:
    public static void conectar() {


        // Crear conexión:
        Connection conexion = null;

        // Crear cadena de conexión:
        String url = "jdbc:mysql://localhost:3306/empresa";

        // Crear usuario y contraseña:
        String usuario = "root";
        String password = "";

        // Intentar conectar:
        try {
            // Conectar:
            conexion = DriverManager.getConnection(url, usuario, password);

            // Verificar conexión:
            if (conexion != null) {
                // Imprimir mensaje:
                System.out.println("Conexión exitosa!");
            }
        } catch (SQLException e) {
            // Imprimir mensaje:
            System.out.println("Error al conectar: " + e.getMessage());
        }
    }

    // Desconectar de la base de datos MySQL usando JDBC:
    public static void desconectar(Connection conexion) {
        // Intentar desconectar:
        try {
            // Verificar conexión:
            if (conexion != null) {
                // Desconectar:
                conexion.close();

                // Imprimir mensaje:
                System.out.println("Desconexión exitosa!");
            }
        } catch (SQLException e) {
            // Imprimir mensaje:
            System.out.println("Error al desconectar: " + e.getMessage());
        }
    }

    // Crear método para consultar los datos de la tabla empleados:
    public static void consultar() {
        // Crear conexión:
        Connection conexion = null;

        // Crear cadena de conexión:
        String url = "jdbc:mysql://localhost:3306/empresa";

        // Crear usuario y contraseña:
        String usuario = "root";
        String password = "";

        // Intentar conectar:
        try {
            // Conectar:
            conexion = DriverManager.getConnection(url, usuario, password);

            // Verificar conexión:
            if (conexion != null) {
                // Imprimir mensaje:
                System.out.println("Conexión exitosa!");
            }
        } catch (SQLException e) {
            // Imprimir mensaje:
            System.out.println("Error al conectar: " + e.getMessage());
        }
    }
}

