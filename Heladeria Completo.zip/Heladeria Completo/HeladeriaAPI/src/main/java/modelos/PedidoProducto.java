package modelos;

import org.javalite.activejdbc.annotations.IdName;
import org.javalite.activejdbc.annotations.Table;

@Table("pedido_producto")
public class PedidoProducto {
}
