package modelos;

import org.javalite.activejdbc.Model;
import org.javalite.activejdbc.annotations.IdName;
import org.javalite.activejdbc.annotations.Table;

@Table("producto")
@IdName("id")
public class Producto extends Model {

}
