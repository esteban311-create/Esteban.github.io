package util;

import org.javalite.activejdbc.Base;
import org.javalite.activejdbc.connection_config.DBConfiguration;

public class Utilidad {
    public static void validateConnection() {
        if(!Base.hasConnection()) {
            DBConfiguration.loadConfiguration("/database.properties");
            Base.open();
        }
    }
}
