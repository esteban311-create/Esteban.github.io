package resources.rest;

import modelos.Rol;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import java.util.List;
import org.javalite.activejdbc.Base;
import org.javalite.activejdbc.connection_config.DBConfiguration;
import util.Utilidad;

@Path("/rol")
public class RolResource {
    @GET
    @Produces("application/json")
    public String get() {

        Utilidad.validateConnection();

        return Rol.findAll().toJson(true);
    }
}
