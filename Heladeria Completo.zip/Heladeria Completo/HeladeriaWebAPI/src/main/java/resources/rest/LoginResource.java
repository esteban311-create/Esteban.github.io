package resources.rest;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.password4j.Password;
import modelos.Usuario;
import modelos.UsuarioDto;
import org.javalite.activejdbc.Base;
import org.javalite.activejdbc.connection_config.DBConfiguration;
import util.Utilidad;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

@Path("/login")
public class LoginResource {
    @POST
    @Consumes("application/json")
    @Produces("application/json")
    public String post(UsuarioDto usuarioDto) {
        Utilidad.validateConnection();

        Usuario usuario = Usuario.findFirst("email = ?", usuarioDto.getEmail());
        Respuesta respuesta = new Respuesta();

        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();

        if (usuario != null) {
            boolean verified = Password.check(usuarioDto.getPassword(), usuario.getString("password")).withBcrypt();
            if (verified) {
                respuesta.setCodigo(200);
                respuesta.setMensaje("Usuario encontrado");
                usuarioDto.setId(usuario.getInteger("id"));
                usuarioDto.setPassword("");
                respuesta.setData(usuarioDto);
            } else {
                respuesta.setCodigo(404);
                respuesta.setMensaje("Contraseña incorrecta");
                respuesta.setData(null);
            }

            return gson.toJson(respuesta);
        } else {
            respuesta.setCodigo(404);
            respuesta.setMensaje("Usuario no encontrado");
            respuesta.setData(null);

            return gson.toJson(respuesta);
        }
    }
}
