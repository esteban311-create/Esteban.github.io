package resources.rest;

import com.google.gson.Gson;
import modelos.*;
import org.javalite.activejdbc.Base;
import org.javalite.activejdbc.connection_config.DBConfiguration;
import util.Utilidad;

import javax.swing.text.Utilities;
import javax.ws.rs.*;
import java.util.List;
import java.util.Map;

@Path("/pedido")
public class PedidoResource {
    @GET
    @Produces("application/json")
    public String get() {
        Utilidad.validateConnection();

        List<Map> resultado = Base.findAll("SELECT P.id, CONCAT(E.nombres, ' ', E.apellidos) AS empleado, CONCAT(C.nombres, ' ', C.apellidos) AS cliente, P.descuento, DATE_FORMAT(P.fecha_hora, '%Y-%m-%d %H:%i:%S') AS fecha_hora FROM cliente AS C INNER JOIN pedido AS P ON C.id = P.cliente_id INNER JOIN empleado AS E ON P.empleado_id = E.id");

        return new Gson().toJson(resultado);
    }

    //obtener pedido por id
    @GET()
    @Path("/{id}")
    @Produces("application/json")

    public String get(@PathParam("id") int id) {
        // DBConfiguration.loadConfiguration("/database.properties");
        //Base.open();

        Utilidad.validateConnection();



        return Pedido.findById(id).toJson(true);
    }

    /**
     * Crea un nuevo pedido.
     */
    @POST
    @Produces("application/json")
    @Consumes("application/json")
    public String post(PedidoDto pedidoDto) {
        Utilidad.validateConnection();

        Pedido pedido = new Pedido();
        pedido.set("descuento", pedidoDto.getDescuento());
        pedido.set("iva", pedidoDto.getIva());
        pedido.set("empleado_id", pedidoDto.getEmpleadoId());
        pedido.set("cliente_id", pedidoDto.getClienteId());
        pedido.saveIt();

        int pedidoId = pedido.getInteger("id");
        for (ProductoDto productoDto : pedidoDto.getProductos()) {
            PedidoProducto pedidoProducto = new PedidoProducto();
            pedidoProducto.set("pedido_id", pedidoId);
            pedidoProducto.set("producto_id", productoDto.getId());
            pedidoProducto.set("cantidad", 1);
            pedidoProducto.set("observacion", productoDto.getObservacion());
            pedidoProducto.saveIt();
        }

        return pedido.toJson(true);
    }

    @GET()
    @Path("/detalles/{pedidoId}")
    @Produces("application/json")
    public String getDetalles(@PathParam("pedidoId") int pedidoId) {
        Utilidad.validateConnection();

        List<Map> resultado = Base.findAll("SELECT P.precio, P.nombre, PP.cantidad, PP.observacion FROM pedido_producto AS PP INNER JOIN producto AS P ON PP.producto_id = P.id WHERE PP.pedido_id = ?", pedidoId);

        return new Gson().toJson(resultado);
    }
}

