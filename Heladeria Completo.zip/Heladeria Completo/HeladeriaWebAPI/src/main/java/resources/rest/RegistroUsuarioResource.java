package resources.rest;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.password4j.Hash;
import com.password4j.Password;
import modelos.Usuario;
import modelos.UsuarioDto;
import org.javalite.activejdbc.Base;
import org.javalite.activejdbc.connection_config.DBConfiguration;
import util.Utilidad;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

@Path("/registro")
public class RegistroUsuarioResource {
    @POST
    @Consumes("application/json")
    @Produces("application/json")
    public String post(UsuarioDto usuarioDto) {
        Utilidad.validateConnection();

        Respuesta respuesta = new Respuesta();
        Usuario usuarioExistente = Usuario.findFirst("email = ?", usuarioDto.getEmail());

        if (usuarioExistente != null) {
            respuesta.setCodigo(404);
            respuesta.setMensaje("El usuario ya existe");
            respuesta.setData(null);
        } else {
            Usuario usuario = new Usuario();
            usuario.set("email", usuarioDto.getEmail());

            Hash hash = Password.hash(usuarioDto.getPassword()).withBcrypt();
            usuario.set("password", hash.getResult());

            usuario.set("rol_id", usuarioDto.getRolId());
            usuario.saveIt();

            respuesta.setCodigo(200);
            respuesta.setMensaje("Usuario registrado");
            usuarioDto.setId(usuario.getInteger("id"));
                respuesta.setData(usuarioDto);
        }

        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();
        return gson.toJson(respuesta);
    }
}
