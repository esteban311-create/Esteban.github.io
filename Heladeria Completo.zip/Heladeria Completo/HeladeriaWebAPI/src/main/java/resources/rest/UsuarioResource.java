package resources.rest;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import modelos.Usuario;
import modelos.UsuarioDto;
import org.javalite.activejdbc.Base;
import org.javalite.activejdbc.connection_config.DBConfiguration;
import util.Utilidad;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

@Path("/usuario")
public class UsuarioResource {
    @GET
    @Produces("application/json")
    public String get() {
       // DBConfiguration.loadConfiguration("/database.properties");
        //Base.open();
        Utilidad.validateConnection();
        return Usuario.findAll().toJson(true);
    }

    // Obtener usuario por id
    @GET()
    @Path("/{id}")
    @Produces("application/json")
    public String get(@PathParam("id") int id) {
        // DBConfiguration.loadConfiguration("/database.properties");
        // Base.open();
        Utilidad.validateConnection();

        UsuarioDto usuarioDto = Usuario.generarDto(Usuario.findById(id));

        Respuesta respuesta = new Respuesta();
        if (usuarioDto != null) {
            respuesta.setCodigo(200);
            respuesta.setMensaje("Usuario encontrado");
            respuesta.setData(usuarioDto);
        } else {
            respuesta.setCodigo(404);
            respuesta.setMensaje("No se encontró el usuario");
            respuesta.setData(null);
        }

        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();
        return gson.toJson(respuesta);
    }
}
