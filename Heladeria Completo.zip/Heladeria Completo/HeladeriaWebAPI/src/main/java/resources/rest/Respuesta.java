package resources.rest;

public class Respuesta {
    private String mensaje;
    private int codigo;
    private Object data;

    public Respuesta() {
    }

    public Respuesta(String mensaje, int codigo, Object data) {
        this.mensaje = mensaje;
        this.codigo = codigo;
        this.data = data;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }
}
