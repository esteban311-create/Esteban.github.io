package resources.rest;

import modelos.Empleado;
import modelos.EmpleadoDto;
import util.Utilidad;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

@Path("/empleado")
public class EmpledoResource {
    // Create a new employee
    @POST
    @Consumes("application/json")
    @Produces("application/json")
    public String post(EmpleadoDto empleadoDto) {
        Utilidad.validateConnection();

        Empleado empleado = new Empleado();
        empleado.set("nombres", empleadoDto.getNombres());
        empleado.set("apellidos", empleadoDto.getApellidos());
        empleado.set("sueldo", empleadoDto.getSueldo());
        empleado.set("fecha_contration", empleadoDto.getFechaContratacion());
        empleado.set("usuario_id", empleadoDto.getUsuarioId());
        empleado.saveIt();

        return empleado.toJson(true);
    }
}
