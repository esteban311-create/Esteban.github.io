package resources.rest;

import modelos.Cliente;
import modelos.ClienteDto;
import util.Utilidad;

import javax.ws.rs.*;

@Path("cliente")
public class ClienteResource {

    @GET()
    @Consumes("application/json")
    @Produces("application/json")
    public String get() {
        Utilidad.validateConnection();

        return Cliente.findAll().toJson(true);
    }

    @POST()
    @Consumes("application/json")
    @Produces("application/json")
    public String post(ClienteDto clienteDto) {
        Utilidad.validateConnection();

        Cliente cliente = new Cliente();
        cliente.set("nombres", clienteDto.getNombres());
        cliente.set("apellidos", clienteDto.getApellidos());
        cliente.set("documento", clienteDto.getDocumento());
        cliente.saveIt();

        return cliente.toJson(true);
    }
}
