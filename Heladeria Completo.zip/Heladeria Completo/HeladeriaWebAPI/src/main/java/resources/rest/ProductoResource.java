package resources.rest;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import modelos.Producto;
import modelos.ProductoDto;
import org.javalite.activejdbc.Base;
import org.javalite.activejdbc.connection_config.DBConfiguration;
import util.Utilidad;

import javax.ws.rs.*;

@Path("/producto")
public class ProductoResource {
    @GET
    @Produces("application/json")
    public String get() {
        Utilidad.validateConnection();

        return Producto.findAll().toJson(true);
    }

    @GET()
    @Path("/{id}")
    @Produces("application/json")
    public String get(@PathParam("id") int id) {
        Utilidad.validateConnection();

        ProductoDto productoDto = Producto.generarDao(Producto.findById(id));

        Respuesta respuesta = new Respuesta();
        if (productoDto != null) {
            respuesta.setCodigo(200);
            respuesta.setMensaje("Producto encontrado");
            respuesta.setData(productoDto);
        } else {
            respuesta.setCodigo(404);
            respuesta.setMensaje("No se encontró el productoDao");
            respuesta.setData(null);
        }

        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();
        return gson.toJson(respuesta);
    }

    @POST
    @Consumes("application/json")
    @Produces("application/json")
    public String post(ProductoDto productoJson) {
        Utilidad.validateConnection();

        Producto producto = new Producto();
        producto.set("nombre", productoJson.getNombre());
        producto.set("precio", productoJson.getPrecio());
        producto.saveIt();

        return producto.toJson(true);
    }
}
