package application;

import filtros.CORSFilter;
import org.glassfish.jersey.server.ResourceConfig;

import javax.ws.rs.ApplicationPath;

//@ApplicationPath("/api/login")
//public class ServerConfig extends ResourceConfig {
//    public ServerConfig() {
//        packages("resources.rest");
//        // register(CORSFilter.class);
//    }
//}
