package modelos;

import org.javalite.activejdbc.Model;
import org.javalite.activejdbc.annotations.IdName;
import org.javalite.activejdbc.annotations.Table;

@Table("producto")
@IdName("id")
public class Producto extends Model {

    public Producto() {
    }

    public Producto(String nombre, double precio) {
        this.set("nombre", nombre);
        this.set("precio", precio);
    }

    public static ProductoDto generarDao(Model producto){
        if (producto == null) {
            return null;
        }

        ProductoDto productoDto = new ProductoDto();
        productoDto.setId(producto.getInteger("id"));
        productoDto.setNombre(producto.getString("nombre"));
        productoDto.setPrecio(producto.getDouble("precio"));
        return productoDto;
    }
}
