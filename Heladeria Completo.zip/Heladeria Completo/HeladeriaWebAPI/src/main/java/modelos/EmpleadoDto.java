package modelos;

public class EmpleadoDto {
    private int id;
    private String nombres;
    private String apellidos;
    private double sueldo;
    private String fechaContratacion;
    private int usuarioId;

    public EmpleadoDto() {
    }

    public EmpleadoDto(String nombres, String apellidos, double sueldo, String fechaContratacion) {
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.sueldo = sueldo;
        this.fechaContratacion = fechaContratacion;
    }

    public EmpleadoDto(int id, String nombres, String apellidos, double sueldo, String fechaContratacion) {
        this.id = id;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.sueldo = sueldo;
        this.fechaContratacion = fechaContratacion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public String getFechaContratacion() {
        return fechaContratacion;
    }

    public void setFechaContratacion(String fechaContratacion) {
        this.fechaContratacion = fechaContratacion;
    }

    public int getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }
}
