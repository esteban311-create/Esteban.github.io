package modelos;

import org.javalite.activejdbc.Model;
import org.javalite.activejdbc.annotations.IdName;
import org.javalite.activejdbc.annotations.Table;

@Table("usuario")
@IdName("id")
public class Usuario extends Model {
    public static UsuarioDto generarDto(Model model) {
        if (model == null) {
            return null;
        }

        UsuarioDto usuarioDto = new UsuarioDto();
        usuarioDto.setId(model.getInteger("id"));
        usuarioDto.setEmail(model.getString("email"));
        usuarioDto.setPassword(model.getString("password"));
        usuarioDto.setRolId(model.getInteger("rol_id"));
        return usuarioDto;
    }
}
