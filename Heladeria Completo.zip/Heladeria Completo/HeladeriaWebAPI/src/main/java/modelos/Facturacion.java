package modelos;

import com.google.gson.Gson;
import util.Utilidad;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

public class Facturacion {
    @Path("/facturacion")
    public static class FacturacionResource {
        @GET
        @Produces("application/json")
        public String get() {
            Utilidad.validateConnection();
            return Facturacion.findAll().toJson(true);
        }
    }

    private static Gson findAll() {
        return null;
    }

}
