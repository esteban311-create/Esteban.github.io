package modelos;

import org.javalite.activejdbc.Model;
import org.javalite.activejdbc.annotations.IdName;
import org.javalite.activejdbc.annotations.Table;

import java.util.ArrayList;
import java.util.List;

@Table("rol")
@IdName("id")
public class Rol extends Model {
    public int id;
    public String nombre;

    public static List<Rol> findAllDao(){
        List<Rol> roles = Rol.findAll();
        List<Rol> roles2 = new ArrayList<Rol>();

        for(Rol rol : roles){
            Rol rol1 = new Rol();
            rol1.id = rol.getInteger("id");
            rol1.nombre = rol.getString("nombre");
            roles2.add(rol1);
        }

        return roles2;
    }
}
