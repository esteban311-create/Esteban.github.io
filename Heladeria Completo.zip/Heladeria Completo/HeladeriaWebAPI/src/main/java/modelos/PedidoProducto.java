package modelos;

import org.javalite.activejdbc.Model;
import org.javalite.activejdbc.annotations.Table;

@Table("pedido_producto")
public class PedidoProducto extends Model {
}
