package modelos;

import java.util.List;

public class PedidoDto {
    private int id;
    private String fechaHora;
    private int descuento;
    private int iva;
    private int empleadoId;
    private int clienteId;

    private List<ProductoDto> productos;

    public PedidoDto() {
    }

    public PedidoDto(String fechaHora, int descuento, int iva, int empleadoId, int clienteId) {
        this.fechaHora = fechaHora;
        this.descuento = descuento;
        this.iva = iva;
        this.empleadoId = empleadoId;
        this.clienteId = clienteId;
    }

    public PedidoDto(int id, String fechaHora, int descuento, int iva, int empleadoId, int clienteId) {
        this.id = id;
        this.fechaHora = fechaHora;
        this.descuento = descuento;
        this.iva = iva;
        this.empleadoId = empleadoId;
        this.clienteId = clienteId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(String fechaHora) {
        this.fechaHora = fechaHora;
    }

    public int getDescuento() {
        return descuento;
    }

    public void setDescuento(int descuento) {
        this.descuento = descuento;
    }

    public int getIva() {
        return iva;
    }

    public void setIva(int iva) {
        this.iva = iva;
    }

    public int getEmpleadoId() {
        return empleadoId;
    }

    public void setEmpleadoId(int empleadoId) {
        this.empleadoId = empleadoId;
    }

    public int getClienteId() {
        return clienteId;
    }

    public void setClienteId(int clienteId) {
        this.clienteId = clienteId;
    }

    public List<ProductoDto> getProductos() {
        return productos;
    }

    public void setProductos(List<ProductoDto> productos) {
        this.productos = productos;
    }
}
