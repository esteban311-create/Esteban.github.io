﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using GestorCitasMedicasCore;

namespace GestorCitasMedicasAccesoDatos
{
    public class AccesoDatos
    {
        private SqlConnection _conexion;
        private SqlCommand _comando;
        private SqlDataReader _reader;

        public string AbrirBd()
        {
            string resultado = "";
            try
            {
                String usuario = "sa";
                String contrasegnia = "Admin2k19";
                String baseDatos = "GestorCitasMedicasBd";
                String cadena = $"Data Source=DESKTOP-AJ3VU7S\\SQLEXPRESS;Initial Catalog={baseDatos};User ID={usuario};Password={contrasegnia}";
                _conexion = new SqlConnection(cadena);
                _conexion.Open();

                resultado = "OK";
            }
            catch (Exception ex)
            {
                resultado = "Falló abrir conexión: " + ex;
            }

            return resultado;
        }

        public Usuario Login(string email, string contrasegnia)
        {
            AbrirBd();

            using (_comando = new SqlCommand("SELECT * FROM usuario WHERE email = @Email AND contrasegnia = @Contrasegnia", _conexion))
            {
                SqlParameter param = new SqlParameter();
                param.ParameterName = "@Email";
                param.Value = email;
                _comando.Parameters.Add(param);
                param = new SqlParameter();
                param.ParameterName = "@Contrasegnia";
                param.Value = contrasegnia;
                _comando.Parameters.Add(param);

                using (_reader = _comando.ExecuteReader())
                {

                    if (_reader.Read())
                    {
                        Usuario usuario = new Usuario();
                        usuario.Id = Int32.Parse(_reader["id"].ToString());
                        usuario.Identificacion = _reader["identificacion"].ToString();
                        usuario.NombreCompleto = _reader["nombre_completo"].ToString();
                        usuario.Email = email;
                        usuario.Contrasegnia = contrasegnia;
                        usuario.Rol = _reader["rol"].ToString();

                        return usuario;
                    }

                    return null;
                }
            }
        }

        public Usuario CrearUsuario(Usuario usuario)
        {
            AbrirBd();

            using (_comando =
                new SqlCommand(
                    "INSERT INTO usuario (nombre_completo, identificacion, email, contrasegnia, rol) VALUES (@NombreCompleto, @Identificacion, @Email, @Contrasegnia, @Rol); SELECT CAST(scope_identity() AS int)",
                    _conexion))
            {
                _comando.Parameters.AddWithValue("@NombreCompleto", usuario.NombreCompleto);
                _comando.Parameters.AddWithValue("@Identificacion", usuario.Identificacion);
                _comando.Parameters.AddWithValue("@Email", usuario.Email);
                _comando.Parameters.AddWithValue("@Contrasegnia", usuario.Contrasegnia);
                _comando.Parameters.AddWithValue("@Rol", usuario.Rol);

                object registro = _comando.ExecuteScalar();

                if (registro != null)
                {
                    usuario.Id = Convert.ToInt32(registro);

                    return usuario;
                }

                return null;
            }
        }

        public DataTable ObtenerUsuarios()
        {
            AbrirBd();
            using (_comando = new SqlCommand("SELECT * FROM usuario", _conexion))
            {
                SqlDataAdapter sda = new SqlDataAdapter(_comando);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                return dt;
            }
        }

        public Usuario ActualizarUsuario(Usuario usuario)
        {
            AbrirBd();

            using (_comando =
                new SqlCommand(
                    "UPDATE usuario SET nombre_completo = @NombreCompleto, identificacion = @Identificacion, email = @Email, contrasegnia = @Contrasegnia, rol = @Rol WHERE id = @Id",
                    _conexion))
            {
                _comando.Parameters.AddWithValue("@NombreCompleto", usuario.NombreCompleto);
                _comando.Parameters.AddWithValue("@Identificacion", usuario.Identificacion);
                _comando.Parameters.AddWithValue("@Email", usuario.Email);
                _comando.Parameters.AddWithValue("@Contrasegnia", usuario.Contrasegnia);
                _comando.Parameters.AddWithValue("@Rol", usuario.Rol);
                _comando.Parameters.AddWithValue("@Id", usuario.Id);

                int registrosModificados = _comando.ExecuteNonQuery();

                return registrosModificados > 0 ? usuario : null;
            }
        }

        public bool EliminarUsuario(int id)
        {
            AbrirBd();

            using (_comando = new SqlCommand("DELETE FROM usuario WHERE id = @Id", _conexion))
            {
                _comando.Parameters.AddWithValue("@Id", id);

                return _comando.ExecuteNonQuery() > 0;
            }
        }

        public Especialista CrearEspecialista(Especialista especialista)
        {
            AbrirBd();

            using (_comando =
                new SqlCommand(
                    "INSERT INTO especialista (nombre_completo, identificacion, email, especialidad, movil) VALUES (@NombreCompleto, @Identificacion, @Email, @Especialidad, @Movil)",
                    _conexion))
            {
                _comando.Parameters.AddWithValue("@NombreCompleto", especialista.NombreCompleto);
                _comando.Parameters.AddWithValue("@Identificacion", especialista.Identificacion);
                _comando.Parameters.AddWithValue("@Email", especialista.Email);
                _comando.Parameters.AddWithValue("@Especialidad", especialista.Especialidad);
                _comando.Parameters.AddWithValue("@Movil", especialista.Movil);

                object registro = _comando.ExecuteScalar();

                if (registro != null)
                {
                    especialista.Id = Convert.ToInt32(registro);

                    return especialista;
                }

                return null;
            }
        }

        public DataTable ObtenerEspecialistas()
        {
            AbrirBd();

            using (_comando = new SqlCommand("SELECT * FROM especialista", _conexion))
            {
                SqlDataAdapter sda = new SqlDataAdapter(_comando);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                return dt;
            }
        }

        public Especialista ActualizarEspecialista(Especialista especialista)
        {
            AbrirBd();

            using (_comando =
                new SqlCommand(
                    "UPDATE especialista SET nombre_completo = @NombreCompleto, identificacion = @Identificacion, email = @Email, especialidad = @Especialidad, movil = @Movil WHERE id = @Id",
                    _conexion))
            {
                _comando.Parameters.AddWithValue("@NombreCompleto", especialista.NombreCompleto);
                _comando.Parameters.AddWithValue("@Identificacion", especialista.Identificacion);
                _comando.Parameters.AddWithValue("@Email", especialista.Email);
                _comando.Parameters.AddWithValue("@Especialidad", especialista.Especialidad);
                _comando.Parameters.AddWithValue("@Movil", especialista.Movil);
                _comando.Parameters.AddWithValue("@Id", especialista.Id);

                int registrosModificados = _comando.ExecuteNonQuery();

                return registrosModificados > 0 ? especialista : null;
            }
        }

        public bool EliminarEspecialista(int id)
        {
            AbrirBd();

            using (_comando =new SqlCommand("DELETE FROM especialista WHERE id = @Id", _conexion))
            {
                _comando.Parameters.AddWithValue("@Id", id);

                return _comando.ExecuteNonQuery() > 0;
            }
        }

        public Consultorio CrearConsultorio(Consultorio consultorio)
        {
            AbrirBd();

            using (_comando =
                new SqlCommand(
                    "INSERT INTO consultorio (nombre, numero, direccion) VALUES (@Nombre, @Numero, @Direccion)",
                    _conexion))
            {
                _comando.Parameters.AddWithValue("@Nombre", consultorio.Nombre);
                _comando.Parameters.AddWithValue("@Numero", consultorio.Numero);
                _comando.Parameters.AddWithValue("@Direccion", consultorio.Direccion);

                object registro = _comando.ExecuteScalar();

                if (registro != null)
                {
                    consultorio.Id = Convert.ToInt32(registro);

                    return consultorio;
                }

                return null;
            }
        }

        public List<Consultorio> ObtenerConsultorios()
        {
            AbrirBd();

            using (_comando = new SqlCommand("SELECT * FROM consultorio", _conexion))
            {
                using (_reader = _comando.ExecuteReader())
                {
                    List<Consultorio> consultorios = new List<Consultorio>();
                    while (_reader.Read())
                    {
                        Consultorio especialista = new Consultorio
                        {
                            Id = int.Parse(_reader["id"].ToString()),
                            Nombre = _reader["nombre"].ToString(),
                            Numero = _reader["numero"].ToString(),
                            Direccion = _reader["direccion"].ToString()
                        };

                        consultorios.Add(especialista);
                    }

                    return consultorios;
                }
            }
        }

        public Consultorio ActualizarConsultorio(Consultorio consultorio)
        {
            AbrirBd();

            using (_comando =
                new SqlCommand(
                    "UPDATE consultorio SET nombre = @Nombre, numero = @Numero, direccion = @Direccion WHERE id = @Id",
                    _conexion))
            {
                _comando.Parameters.AddWithValue("@Nombre", consultorio.Nombre);
                _comando.Parameters.AddWithValue("@Numero", consultorio.Numero);
                _comando.Parameters.AddWithValue("@Direccion", consultorio.Direccion);
                _comando.Parameters.AddWithValue("@Id", consultorio.Id);

                int registrosModificados = _comando.ExecuteNonQuery();

                return registrosModificados > 0 ? consultorio : null;
            }
        }

        public bool EliminarConsultorio(int id)
        {
            AbrirBd();

            using (_comando = new SqlCommand("DELETE FROM consultorio WHERE id = @Id", _conexion))
            {
                _comando.Parameters.AddWithValue("@Id", id);

                return _comando.ExecuteNonQuery() > 0;
            }
        }

        public Cita CrearCita(Cita cita)
        {
            AbrirBd();

            using (_comando =
                new SqlCommand(
                    "INSERT INTO cita (estado, fecha, observaciones, consultorio_id, usuario_id, especialista_id) VALUES (@Estado, @Fecha, @Observaciones, @ConsultorioId, @UsuarioId, @EspecialistaId)",
                    _conexion))
            {
                _comando.Parameters.AddWithValue("@Estado", cita.Estado);
                _comando.Parameters.AddWithValue("@Fecha", cita.Fecha);
                _comando.Parameters.AddWithValue("@Observaciones", cita.Observaciones);
                _comando.Parameters.AddWithValue("@ConsultorioId", cita.ConsultorioId);
                _comando.Parameters.AddWithValue("@UsuarioId", cita.UsuarioId);
                _comando.Parameters.AddWithValue("@EspecialistaId", cita.EspecialistaId);

                object registro = _comando.ExecuteScalar();

                if (registro != null)
                {
                    cita.Id = Convert.ToInt32(registro);

                    return cita;
                }

                return null;
            }
        }

        public List<Cita> ObtenerCitas()
        {
            AbrirBd();

            using (_comando = new SqlCommand("SELECT * FROM cita", _conexion))
            {
                using (_reader = _comando.ExecuteReader())
                {
                    List<Cita> citas = new List<Cita>();
                    while (_reader.Read())
                    {
                        Cita cita = new Cita
                        {
                            Id = int.Parse(_reader["id"].ToString()),
                            Estado = Int32.Parse(_reader["estado"].ToString()),
                            Fecha = _reader["fecha"].ToString(),
                            Observaciones= _reader["observaciones"].ToString(),
                            ConsultorioId = int.Parse(_reader["consultorio_id"].ToString()),
                            UsuarioId = int.Parse(_reader["usuario_id"].ToString()),
                            EspecialistaId = int.Parse(_reader["especialista_id"].ToString())
                        };

                        citas.Add(cita);
                    }

                    return citas;
                }
            }
        }

        public DataTable ObtenerCitas(Usuario usuario)
        {
            AbrirBd();
            using (_comando = new SqlCommand("SELECT c.id id, c.estado estado, c.fecha fecha, c.observaciones observaciones, U.nombre_completo nombre_completo, U.identificacion identificacion, E.nombre_completo nombre_completo_especialista, O.nombre nombre  FROM cita C INNER JOIN usuario U ON C.usuario_id = U.id INNER JOIN especialista E ON C.especialista_id = E.id INNER JOIN consultorio O ON C.consultorio_id = O.id WHERE U.email = @Email", _conexion))
            {
                _comando.Parameters.AddWithValue("@Email", usuario.Email);

                SqlDataAdapter sda = new SqlDataAdapter(_comando);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                return dt;
            }
        }

        public Cita ActualizarCita(Cita cita)
        {
            AbrirBd();

            using (_comando =
                new SqlCommand(
                    "UPDATE cita SET estado = @Estado, fecha = @Fecha, observaciones = @Observaciones, consultorio_id= @ConsultorioId, usuario_id = @UsuarioId, especialidad_id = @EspecialidadId WHERE id = @Id",
                    _conexion))
            {
                _comando.Parameters.AddWithValue("@Estado", cita.Estado);
                _comando.Parameters.AddWithValue("@fecha", cita.Fecha);
                _comando.Parameters.AddWithValue("@Observaciones", cita.Observaciones);
                _comando.Parameters.AddWithValue("@ConsultorioId", cita.ConsultorioId);
                _comando.Parameters.AddWithValue("@UsuarioId", cita.UsuarioId);
                _comando.Parameters.AddWithValue("@EspecialistaId", cita.EspecialistaId);
                _comando.Parameters.AddWithValue("@Id", cita.Id);

                int registrosModificados = _comando.ExecuteNonQuery();

                return registrosModificados > 0 ? cita : null;
            }
        }

        public bool EliminarCita(int id)
        {
            AbrirBd();

            using (_comando = new SqlCommand("DELETE FROM cita WHERE id = @Id", _conexion))
            {
                _comando.Parameters.AddWithValue("@Id", id);

                return _comando.ExecuteNonQuery() > 0;
            }
        }

        public DataTable ObtenerCitasDatos()
        {
            AbrirBd();
            using (_comando = new SqlCommand("SELECT c.id id, c.estado estado, c.fecha fecha, c.observaciones observaciones, U.nombre_completo nombre_completo, U.identificacion identificacion, E.nombre_completo nombre_completo_especialista, O.nombre nombre  FROM cita C INNER JOIN usuario U ON C.usuario_id = U.id INNER JOIN especialista E ON C.especialista_id = E.id INNER JOIN consultorio O ON C.consultorio_id = O.id", _conexion))
            {
                SqlDataAdapter sda = new SqlDataAdapter(_comando);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                return dt;
            }
        }

        public Usuario BuscarUsuarioPorEmail(string email)
        {
            AbrirBd();

            using (_comando = new SqlCommand("SELECT * FROM usuario WHERE email = @Email", _conexion))
            {
                SqlParameter param = new SqlParameter();
                param.ParameterName = "@Email";
                param.Value = email;
                _comando.Parameters.Add(param);

                using (_reader = _comando.ExecuteReader())
                {

                    if (_reader.HasRows && _reader.Read())
                    {
                        Usuario usuario = new Usuario();
                        usuario.Id = Int32.Parse(_reader["id"].ToString());
                        usuario.Identificacion = _reader["identificacion"].ToString();
                        usuario.NombreCompleto = _reader["nombre_completo"].ToString();
                        usuario.Email = email;
                        usuario.Contrasegnia = _reader["contrasegnia"].ToString();
                        usuario.Rol = _reader["rol"].ToString();

                        return usuario;
                    }

                    return null;
                }
            }
        }

        public Usuario BuscarUsuarioPorId(int id)
        {
            AbrirBd();

            using (_comando = new SqlCommand("SELECT * FROM usuario WHERE id = @Id", _conexion))
            {
                SqlParameter param = new SqlParameter();
                param.ParameterName = "@Id";
                param.Value = id;
                _comando.Parameters.Add(param);

                using (_reader = _comando.ExecuteReader())
                {

                    if (_reader.Read())
                    {
                        Usuario usuario = new Usuario();
                        usuario.Id = Int32.Parse(_reader["id"].ToString());
                        usuario.Identificacion = _reader["identificacion"].ToString();
                        usuario.NombreCompleto = _reader["nombre_completo"].ToString();
                        usuario.Email = _reader["email"].ToString();
                        usuario.Contrasegnia = _reader["contrasegnia"].ToString();
                        usuario.Rol = _reader["rol"].ToString();

                        return usuario;
                    }

                    return null;
                }
            }
        }
    }
}
