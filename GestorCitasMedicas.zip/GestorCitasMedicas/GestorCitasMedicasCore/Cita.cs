using System;

namespace GestorCitasMedicasCore
{
    public class Cita
    {

        private Consultorio Consultorio { get; set; }
        private Especialista Especialista { get; set; }
        public int Estado { get; set; }
        public String Fecha { get; set; }
        public int Id { get; set; }
        public string Observaciones { get; set; }
        public int ConsultorioId { get; set; }
        public int EspecialistaId { get; set; }
        public int UsuarioId { get; set; }

        public Cita()
        {

        }

        public Cita(int estado, String fecha, int id, string observaciones)
        {
            Estado = estado;
            Fecha = fecha;
            Id = id;
            Observaciones = observaciones;
        }

        public Cita(Consultorio consultorio, Especialista especialista, int estado, String fecha, int id, string observaciones)
        {
            Consultorio = consultorio;
            Especialista = especialista;
            Estado = estado;
            Fecha = fecha;
            Id = id;
            Observaciones = observaciones;
        }

        public Cita(int estado, String fecha, int id, string observaciones, int consultorioId, int especialistaId, int usuarioId)
        {
            Estado = estado;
            Fecha = fecha;
            Id = id;
            Observaciones = observaciones;
            ConsultorioId = consultorioId;
            EspecialistaId = especialistaId;
            UsuarioId = usuarioId;
        }
    }
}