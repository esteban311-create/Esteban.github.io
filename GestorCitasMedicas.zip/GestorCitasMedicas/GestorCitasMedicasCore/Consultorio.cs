using System;

namespace GestorCitasMedicasCore
{
    public class Consultorio
    {

        public string Direccion { get; set; }
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Numero { get; set; }

        public Consultorio()
        {

        }

        public Consultorio(string direccion, int id, string nombre, string numero)
        {
            Direccion = direccion;
            Id = id;
            Nombre = nombre;
            Numero = numero;
        }

        public Consultorio(string direccion, string nombre, string numero)
        {
            Direccion = direccion;
            Nombre = nombre;
            Numero = numero;
        }
    }
}
