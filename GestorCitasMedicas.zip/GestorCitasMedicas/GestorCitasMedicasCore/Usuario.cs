using System;
using System.Collections.Generic;

namespace GestorCitasMedicasCore
{
    public class Usuario
    {

        private List<Cita> Citas;
        public string Contrasegnia { get; set; }
        public string NombreCompleto { get; set; }
        public string Email { get; set; }
        public int Id { get; set; }
        public string Identificacion { get; set; }
        public string Rol { get; set; }

        public Usuario()
        {

        }

        public Usuario(string nombreCompleto, string contrasegnia, string email, int id, string identificacion, string rol)
        {
            NombreCompleto = nombreCompleto;
            Contrasegnia = contrasegnia;
            Email = email;
            Id = id;
            Identificacion = identificacion;
            Rol = rol;
        }

        public Usuario(string nombreCompleto, string contrasegnia, string email, string identificacion, string rol)
        {
            NombreCompleto = nombreCompleto;
            Contrasegnia = contrasegnia;
            Email = email;
            Identificacion = identificacion;
            Rol = rol;
        }
    }
}