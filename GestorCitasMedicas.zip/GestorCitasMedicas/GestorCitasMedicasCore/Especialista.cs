using System;
using System.Collections.Generic;
using System.Text;
using System.IO;


namespace GestorCitasMedicasCore
{
    public class Especialista
    {

        public string Email { get; set; }
        public string Especialidad { get; set; }
        public  int Id { get; set; }
        public string Identificacion { get; set; }
        public string Movil { get; set; }
        public string NombreCompleto { get; set; }


        public Especialista()
        {

        }

        public Especialista(string email, string especialidad, int id, string identificacion, string movil, string nombreCompleto)
        {
            Email = email;
            Especialidad = especialidad;
            Id = id;
            Identificacion = identificacion;
            Movil = movil;
            NombreCompleto = nombreCompleto;
        }

        public Especialista(string email, string especialidad, string identificacion, string movil, string nombreCompleto)
        {
            Email = email;
            Especialidad = especialidad;
            Identificacion = identificacion;
            Movil = movil;
            NombreCompleto = nombreCompleto;
        }
    }
}
