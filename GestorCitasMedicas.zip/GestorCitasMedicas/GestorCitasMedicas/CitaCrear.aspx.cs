﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GestorCitasMedicasAccesoDatos;
using GestorCitasMedicasCore;

namespace GestorCitasMedicas
{
    public partial class CitaCrear : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                CargarDatos();
            }
        }

        private void CargarDatos()
        {
            AccesoDatos accesoDatos = new AccesoDatos();

            List<Consultorio> consultorios = accesoDatos.ObtenerConsultorios();
            foreach (Consultorio c in consultorios)
            {
                cbxConsultorios.Items.Add(new ListItem(c.Nombre + " (" + c.Direccion + " )", c.Id.ToString()));
            }

            DataTable especialistasTabla = accesoDatos.ObtenerEspecialistas();
            foreach (DataRow dr in especialistasTabla.Rows)
            {
                cbxEspecialistas.Items.Add(new ListItem(dr["nombre_completo"].ToString() + " (" + dr["identificacion"].ToString() + ")", dr["id"].ToString()));
            }
        }

        protected void btnCrearCita_Click(object sender, EventArgs e)
        {
            string consultorio = cbxConsultorios.SelectedItem.Value;
            string especialista = cbxEspecialistas.SelectedItem.Value;
            int estado = Int32.Parse(cbxEstado.SelectedItem.Value);
            string fecha = txtFecha.Text;
            string observaciones = txtObservaciones.Text;

            Cita cita = new Cita();
            cita.ConsultorioId = Int32.Parse(consultorio);
            cita.EspecialistaId = Int32.Parse(especialista);
            cita.Estado = estado;
            cita.Fecha = DateTime.Parse(fecha, null, System.Globalization.DateTimeStyles.RoundtripKind).ToString();
            cita.Observaciones = observaciones;
            cita.UsuarioId = (Session["Usuario"] as Usuario).Id;

            AccesoDatos accesoDatos = new AccesoDatos();
            accesoDatos.CrearCita(cita);

            Response.Redirect("Citas.aspx");
        }
    }
}