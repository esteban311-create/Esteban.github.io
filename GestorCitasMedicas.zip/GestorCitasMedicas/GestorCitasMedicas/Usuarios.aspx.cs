﻿using System;
using System.Web.UI.WebControls;
using GestorCitasMedicasAccesoDatos;
using GestorCitasMedicasCore;

namespace GestorCitasMedicas
{
    public partial class Usuarios : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                CargarDatos();
            }
        }

        private void CargarDatos()
        {
            gvwUsuarios.DataSource = new AccesoDatos().ObtenerUsuarios();
            gvwUsuarios.DataBind();
        }

        protected void btnCrearUsuario_Click(object sender, EventArgs e)
        {
            Response.Redirect("UsuarioCrear.aspx");
        }

        protected void gvwUsuarios_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvwUsuarios.EditIndex = -1;
            CargarDatos();
        }

        protected void gvwUsuarios_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id = Convert.ToInt32(gvwUsuarios.DataKeys[e.RowIndex].Values["id"].ToString());

            AccesoDatos accesoDatos = new AccesoDatos();

            Usuario usuario = accesoDatos.BuscarUsuarioPorId(id);

            if (accesoDatos.ObtenerCitas(usuario).Rows.Count == 0)
            {
                divMensajes.Visible = false;
                accesoDatos.EliminarUsuario(id);
                CargarDatos();
            }
            else
            {
                divMensajes.Visible = true;
                lblMensajes.Text = "El usuario tiene citas. Debe borrar primero las citas.";
            }
        }

        protected void gvwUsuarios_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvwUsuarios.EditIndex = e.NewEditIndex;
            CargarDatos();
        }

        protected void gvwUsuarios_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            Usuario usuario = new Usuario();

            usuario.Id = Convert.ToInt32(gvwUsuarios.DataKeys[e.RowIndex].Values["id"].ToString());
            usuario.NombreCompleto = (gvwUsuarios.Rows[e.RowIndex].FindControl("txtNombreCompleto") as TextBox).Text;
            usuario.Identificacion = (gvwUsuarios.Rows[e.RowIndex].FindControl("txtIdentificacion") as TextBox).Text;
            usuario.Email = (gvwUsuarios.Rows[e.RowIndex].FindControl("txtEmail") as TextBox).Text;
            usuario.Contrasegnia = (gvwUsuarios.Rows[e.RowIndex].FindControl("txtContrasegnia") as TextBox).Text;
            usuario.Rol = (gvwUsuarios.Rows[e.RowIndex].FindControl("txtRol") as TextBox).Text;

            new AccesoDatos().ActualizarUsuario(usuario);
            gvwUsuarios.EditIndex = -1;

            CargarDatos();
        }
    }
}