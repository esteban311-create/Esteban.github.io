﻿using System;
using GestorCitasMedicasAccesoDatos;

namespace GestorCitasMedicas
{
    public partial class CitasAdmin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                CargarDatos();
            }
        }

        private void CargarDatos()
        {
            gvwCitas.DataSource = new AccesoDatos().ObtenerCitasDatos();
            gvwCitas.DataBind();
        }

        protected void btnCrearCita_Click(object sender, EventArgs e)
        {
            Response.Redirect("CitaCrear.aspx");
        }
    }
}