﻿using System;
using GestorCitasMedicasAccesoDatos;
using GestorCitasMedicasCore;

namespace GestorCitasMedicas
{
    public partial class Citas : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                CargarDatos();
            }
        }

        private void CargarDatos()
        {
            Usuario usuario = Session["Usuario"] as Usuario;
            gvwCitas.DataSource = new AccesoDatos().ObtenerCitas(usuario);
            gvwCitas.DataBind();
        }

        protected void btnCrearCita_Click(object sender, EventArgs e)
        {
            Response.Redirect("CitaCrear.aspx");
        }

        protected void gvwCitas_RowDeleting(object sender, System.Web.UI.WebControls.GridViewDeleteEventArgs e)
        {
            int id = Convert.ToInt32(gvwCitas.DataKeys[e.RowIndex].Values["id"].ToString());

            new AccesoDatos().EliminarCita(id);

            CargarDatos();
        }
    }
}