﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GestorCitasMedicasCore;

namespace GestorCitasMedicas
{
    public partial class SiteMaster : MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                ComprobarOpcionesMenu();
            }
        }

        private void ComprobarOpcionesMenu()
        {
            Usuario usuario = Session["Usuario"] as Usuario;

            if (usuario != null)
            {
                litLogin.Visible = false;
                litRegistro.Visible = false;

                if (usuario.Rol.Equals("ADMIN"))
                {
                    litConsultorios.Visible = true;
                    litEspecialistas.Visible = true;
                    litUsuarios.Visible = true;
                    litGestionCitas.Visible = true;
                }
                else
                {
                    litCitas.Visible = true;
                }

                litCerrarSesion.Visible = true;
            }
            else
            {
                litCerrarSesion.Visible = false;
            }
        }

        protected void OnServerClick(object sender, EventArgs e)
        {
            Session.Remove("Usuario");
            Session.Remove("Rol");
            Response.Redirect("Default.aspx");
        }
    }
}