﻿using System;
using GestorCitasMedicasAccesoDatos;
using GestorCitasMedicasCore;

namespace GestorCitasMedicas
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                divMensajes.Visible = false;
            }
        }

        protected void btnIniciarSesion_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text;
            string contrasegnia = txtContrasegnia.Text;

            if (!email.Equals(String.Empty) && !contrasegnia.Equals(String.Empty))
            {
                AccesoDatos accesoDatos = new AccesoDatos();

                Usuario usuario = accesoDatos.Login(email, contrasegnia);

                if (usuario != null)
                {
                    Session["Usuario"] = usuario;
                    Session["Rol"] = usuario.Rol;
                    if (usuario.Rol.Equals("ADMIN"))
                    {
                        Response.Redirect("CitasAdmin.aspx");
                    }
                    else
                    {
                        Response.Redirect("Citas.aspx");
                    }
                }
                else
                {
                    divMensajes.Visible = true;
                    lblMensajes.Text = "Los datos de acceso no son válidos. Intente nuevamente.";
                }
            }
            else
            {
                divMensajes.Visible = true;
                lblMensajes.Text = "Todos los campos son obligatorios.";
            }
        }
    }
}