﻿using System;
using System.Web.UI.WebControls;
using GestorCitasMedicasAccesoDatos;
using GestorCitasMedicasCore;

namespace GestorCitasMedicas
{
    public partial class Especialistas : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                CargarDatos();
            }
        }

        private void CargarDatos()
        {
            gvwEspecialistas.DataSource = new AccesoDatos().ObtenerEspecialistas();
            gvwEspecialistas.DataBind();
        }

        protected void gvwEspecialistas_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            Especialista especialista = new Especialista();

            especialista.Id = Convert.ToInt32(gvwEspecialistas.DataKeys[e.RowIndex].Values["id"].ToString());
            especialista.NombreCompleto = (gvwEspecialistas.Rows[e.RowIndex].FindControl("txtNombreCompleto") as TextBox).Text;
            especialista.Identificacion = (gvwEspecialistas.Rows[e.RowIndex].FindControl("txtIdentificacion") as TextBox).Text;
            especialista.Email = (gvwEspecialistas.Rows[e.RowIndex].FindControl("txtEmail") as TextBox).Text;
            especialista.Especialidad = (gvwEspecialistas.Rows[e.RowIndex].FindControl("txtEspecialidad") as TextBox).Text;
            especialista.Movil = (gvwEspecialistas.Rows[e.RowIndex].FindControl("txtEspecialidad") as TextBox).Text;

            new AccesoDatos().ActualizarEspecialista(especialista);
            gvwEspecialistas.EditIndex = -1;
            CargarDatos();
        }

        protected void gvwEspecialistas_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvwEspecialistas.EditIndex = -1;
            CargarDatos();
        }

        protected void gvwEspecialistas_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id = Convert.ToInt32(gvwEspecialistas.DataKeys[e.RowIndex].Values["id"].ToString());

            AccesoDatos accesoDatos = new AccesoDatos();

            Cita cita = accesoDatos.ObtenerCitas().Find(c => c.EspecialistaId == id);

            if (cita == null)
            {
                accesoDatos.EliminarEspecialista(id);
                CargarDatos();
                divMensajes.Visible = false;
            }
            else
            {
                divMensajes.Visible = true;
                lblMensajes.Text =
                    "El espacialista está encargado al menos de una cita. Primero debe eliminar las citas a cargo de este especialista.";
            }
        }

        protected void gvwEspecialistas_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvwEspecialistas.EditIndex = e.NewEditIndex;
            CargarDatos();
        }

        protected void btnAgregarEspecialista_Click(object sender, EventArgs e)
        {
            Response.Redirect("EspecialistaCrear.aspx");
        }
    }
}