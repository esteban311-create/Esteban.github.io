﻿using System;
using GestorCitasMedicasAccesoDatos;
using GestorCitasMedicasCore;

namespace GestorCitasMedicas
{
    public partial class RegistroUsuario : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                divMensajes.Visible = false;
            }
        }

        protected void btnRegistrarUsuario_Click(object sender, EventArgs e)
        {
            string nombreCompleto = txtNombreCompleto.Text;
            string identificacion = txtIdentificacion.Text;
            string email = txtEmail.Text;
            string contrasegnia = txtContrasegnia.Text;
            string contrasegniaRepetir = txtContrasegniaRepetir.Text;
            string rol = cbxRoles.SelectedValue;

            if (!nombreCompleto.Equals(string.Empty) && !identificacion.Equals(String.Empty) &&
                !email.Equals(String.Empty) && !contrasegnia.Equals(String.Empty) &&
                !contrasegniaRepetir.Equals(String.Empty))
            {
                if (contrasegnia.Equals(contrasegniaRepetir))
                {
                    AccesoDatos accesoDatos = new AccesoDatos();

                    if (accesoDatos.BuscarUsuarioPorEmail(email) == null)
                    {
                        Usuario usuario = new Usuario(nombreCompleto, contrasegnia, email, identificacion, rol);

                        if (accesoDatos.CrearUsuario(usuario) != null)
                        {
                            Response.Redirect("Login.aspx");
                        }
                        else
                        {
                            divMensajes.Visible = true;
                            lblMensajes.Text = "No se ha podido crear el usuario. Intente nuevamente.";
                        }
                    }
                    else
                    {
                        divMensajes.Visible = true;
                        lblMensajes.Text = "Ya existe un usuario con el email indicado.";
                    }
                }
                else
                {
                    divMensajes.Visible = true;
                    lblMensajes.Text = "Las contraseñas no coinciden.";
                }
            }
            else
            {
                divMensajes.Visible = true;
                lblMensajes.Text = "Todos los campos son obligatorios.";
            }
        }
    }
}