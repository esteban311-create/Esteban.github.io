﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GestorCitasMedicasAccesoDatos;
using GestorCitasMedicasCore;

namespace GestorCitasMedicas
{
    public partial class EspecialistaCrear : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCrearEspecialista_Click(object sender, EventArgs e)
        {
            string nombreCompleto = txtNombreCompleto.Text;
            string identificacion = txtIdentificacion.Text;
            string email = txtEmail.Text;
            string especialidad = cbxEspecialidades.SelectedValue;
            string movil = txtMovil.Text;

            Especialista especialista = new Especialista(email, especialidad, identificacion, movil, nombreCompleto);

            AccesoDatos accesoDatos = new AccesoDatos();
            accesoDatos.CrearEspecialista(especialista);

            Response.Redirect("Especialistas.aspx");
        }
    }
}