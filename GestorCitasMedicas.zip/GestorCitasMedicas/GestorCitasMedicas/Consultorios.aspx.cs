﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using GestorCitasMedicasAccesoDatos;
using GestorCitasMedicasCore;

namespace GestorCitasMedicas
{
    public partial class Consultorios : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                CargarDatos();
            }
        }

        private void CargarDatos()
        {
            gvwConsultorios.DataSource = new AccesoDatos().ObtenerConsultorios();
            gvwConsultorios.DataBind();
        }

        protected void gvwConsultorios_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvwConsultorios.EditIndex = -1;
            CargarDatos();
        }

        protected void gvwConsultorios_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id = Convert.ToInt32(gvwConsultorios.DataKeys[e.RowIndex].Values["id"].ToString());

            AccesoDatos accesoDatos = new AccesoDatos();

            Cita cita = accesoDatos.ObtenerCitas().Find(c => c.ConsultorioId == id);

            if (cita == null)
            {
                new AccesoDatos().EliminarConsultorio(id);
                CargarDatos();
                divMensajes.Visible = false;
            }
            else
            {
                divMensajes.Visible = true;
                lblMensajes.Text =
                    "El consultorio está asignado a citas. Primero debe eliminar las citas asociadas a este consultorio.";
            }
        }

        protected void gvwConsultorios_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvwConsultorios.EditIndex = e.NewEditIndex;
            CargarDatos();
        }

        protected void gvwConsultorios_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            Consultorio consultorio = new Consultorio();

            consultorio.Id = Convert.ToInt32(gvwConsultorios.DataKeys[e.RowIndex].Values["id"].ToString());
            consultorio.Nombre = (gvwConsultorios.Rows[e.RowIndex].FindControl("txtNombre") as TextBox).Text;
            consultorio.Numero = (gvwConsultorios.Rows[e.RowIndex].FindControl("txtNumero") as TextBox).Text;
            consultorio.Direccion = (gvwConsultorios.Rows[e.RowIndex].FindControl("txtDireccion") as TextBox).Text;

            new AccesoDatos().ActualizarConsultorio(consultorio);
            gvwConsultorios.EditIndex = -1;
            CargarDatos();
        }

        protected void btnCrearConsultorio_Click(object sender, EventArgs e)
        {
            Response.Redirect("ConsultarioCrear.aspx");
        }
    }
}