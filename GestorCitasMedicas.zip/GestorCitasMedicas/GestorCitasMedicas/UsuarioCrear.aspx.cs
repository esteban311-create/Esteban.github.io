﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GestorCitasMedicasAccesoDatos;
using GestorCitasMedicasCore;

namespace GestorCitasMedicas
{
    public partial class UsuarioCrear : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCrearUsuario_Click(object sender, EventArgs e)
        {
            Usuario usuario = new Usuario();
            usuario.NombreCompleto = txtNombreCompleto.Text;
            usuario.Identificacion = txtIdentificacion.Text;
            usuario.Email = txtEmail.Text;
            usuario.Contrasegnia = txtContrasegnia.Text;
            usuario.Rol = cbxRoles.SelectedValue;

            new AccesoDatos().CrearUsuario(usuario);

            Response.Redirect("Usuarios.aspx");
        }
    }
}